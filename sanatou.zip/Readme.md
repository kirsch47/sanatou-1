Install
============

Neo4J
-----
- EC2 Start Ubuntu 13.04 64 bit on M1.medium
- Alter Comment IP neo4j-server.properties
- Install Oracle Java // http://nikolas.demiridis.gr/post/51149977942/neo4j-install-on-ubuntu-lazy-admin-way
- http://ec2-54-226-209-242.compute-1.amazonaws.com:7474

Nodejs
------

